import base64, zlib, codecs, re, binascii

def try_hex(s):
    s = s.strip()
    if re.fullmatch(r'[0-9a-fA-F]+', s) and len(s) % 2 == 0:
        try:
            return binascii.unhexlify(s)
        except:
            pass
    return None

def try_strrev(s):
    return s[::-1]

def try_chr_chain(s):
    matches = re.findall(r'chr\((\d+)\)', s)
    if matches and len(matches) > 5:
        try:
            return ''.join(chr(int(x)) for x in matches).encode()
        except:
            pass
    return None

def smart_decode(data: bytes):
    text = data.decode("utf-8", errors="ignore")

    # ROT13 → B64 → ZLIB
    try:
        rot = codecs.decode(text, "rot_13")
        b = base64.b64decode(rot)
        return zlib.decompress(b), "rot13+b64+zlib"
    except:
        pass

    # STRREV → B64
    try:
        rev = try_strrev(text)
        b = base64.b64decode(rev)
        return b, "strrev+b64"
    except:
        pass

    # HEX
    h = try_hex(text)
    if h:
        return h, "hex"

    # CHR chain
    c = try_chr_chain(text)
    if c:
        return c, "chr-chain"

    return data, None


data = open("FINAL_RESULT.txt", "rb").read()
layer = 1

while True:
    new, method = smart_decode(data)
    if not method:
        print(f"[✓] STOP di layer {layer}")
        break

    print(f"[+] Layer {layer}: {method}")
    open(f"layerX_{layer}.txt", "wb").write(new)
    data = new
    layer += 1

open("ULTRA_FINAL.txt", "wb").write(data)
print("🔥 ULTRA_FINAL.txt siap dibaca")
